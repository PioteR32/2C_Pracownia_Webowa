<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <p>
        <?php
            $name = $_POST['name'];
            $surname = $_POST['surname'];
            $email = $_POST['mail'];
            $password = $_POST['password'];
            $birth_date = $_POST['birth_date'];
            $street = $_POST['street'];
            $house = $_POST['houseNumber'];
            $apartment = $_POST['apartmentNumber'];
            $post_code = $_POST['post_code'];
            
            echo "Imię: $name<br>";
            echo "Nazwisko: $surname<br>";
            echo "E-mail: $email<br>";
            echo "Hasło: $password<br>";
            echo "Data urodzenia: $birth_date<br>";

            if(!empty($apartment))
                echo "Adres: $street / $house  m. $apartment  $post_code<br>";
             else
                echo "Adres: $street / $house  $post_code<br>";
        ?>
    </p>
</body>
</html>